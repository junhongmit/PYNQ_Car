#ifndef __XLWIPCONFIG_H_
#define __XLWIPCONFIG_H_


/* This is a generated file - do not edit */

#define XLWIP_CONFIG_INCLUDE_GEM 1
#define XLWIP_CONFIG_EMAC_NUMBER 0
#define XLWIP_CONFIG_N_TX_DESC 64
#define XLWIP_CONFIG_N_RX_DESC 64

#endif
